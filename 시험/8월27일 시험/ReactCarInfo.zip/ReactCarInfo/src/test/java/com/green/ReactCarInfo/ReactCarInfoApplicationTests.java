package com.green.ReactCarInfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactCarInfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
