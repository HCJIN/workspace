package test;

import java.util.Arrays;
import java.util.Scanner;

public class Test5 {
    public static void main(String[] args) {
        int[] arr = new int[3];
        int[] input = new int[3];
        int strike = 0;
        int ball = 0;
        int cnt = 0;

        for (int i = 0; i<arr.length; i++){
            int rand = (int)(Math.random()*9 + 1);
            arr[i] = rand;
            for(int j = 0; j < i; j++){
                if(arr[j] == arr[i]){
                    i--;
                    break;
                }
            }
        }

        System.out.println(Arrays.toString(arr));
        System.out.println("숫자를 정했습니다. 게임을 시작합니다.");

        Scanner sc = new Scanner(System.in);

        while(true){
            cnt++;
            System.out.print(cnt + " >> ");
            for (int i = 0; i < input.length; i++){
                input[i] = sc.nextInt();
                for (int j = 0; j < i; j++){
                    if(input[i] == input[j]){
                        System.out.println("중복된 값 입력");
                        i--;
                        break;
                    }
                }
            }
            for(int i = 0; i < arr.length; i++){
                for (int j = 0; j < input.length; j++){
                    if (arr[i] == input[j] && i == j){
                        strike++;
                    } else if (arr[i] == input[j] && i != j) {
                        ball++;
                    }
                }
            }

            System.out.println(strike + "스트라이크" + ball + "볼");
                if(strike == 3){
                    System.out.println(cnt + "회만에 정답을 맞췄습니다");
                    break;
                }

                strike = 0;
                ball = 0;

        }

    }
}
