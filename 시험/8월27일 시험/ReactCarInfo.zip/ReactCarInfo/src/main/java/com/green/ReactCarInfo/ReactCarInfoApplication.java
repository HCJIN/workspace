package com.green.ReactCarInfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactCarInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactCarInfoApplication.class, args);
	}

}
