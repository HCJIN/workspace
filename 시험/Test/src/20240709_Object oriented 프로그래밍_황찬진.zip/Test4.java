package test;

import java.util.Scanner;

public class Test4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("1~999까지의 임의의 숫자를 입력하시오 : ");
        int num = sc.nextInt();

        while (true){

            if(num < 0 || num > 999){
                System.out.print("다시 입력 하시오 : ");
                num = sc.nextInt();
            }else{
                int cnt = 0;

                if(num / 100 == 3 || num / 100 == 6 || num / 100 == 9){
                    cnt++;
                }
                if((num / 10) % 10 == 3 || (num / 10) % 10 == 6 || (num / 10) % 10 == 9){
                    cnt++;
                }
                if(num % 10 == 3 || num % 10 == 6 || num % 10 == 9){
                    cnt++;
                }

                if(cnt == 3){
                    System.out.println("박수 3번");
                } else if (cnt == 2) {
                    System.out.println("박수 2번");
                } else if (cnt == 1) {
                    System.out.println("박수 1번");
                }else{
                    System.out.println("박수 0번");
                }
                break;
            }
        }
    }
}
